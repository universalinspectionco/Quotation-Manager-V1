@echo off
setlocal
cd /d "%~dp0"
title UIC Quotation Manager - Universal Inspection Co. Ltd.

:: 1. Launch with compiled native launcher if available
if exist "%~dp0UIC Quotation Manager.exe" (
    start "" "%~dp0UIC Quotation Manager.exe"
    exit /b
)

:: 2. Launch with Microsoft Edge
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="file:///%~dp0index.html" --window-size=1366,860 --allow-file-access-from-files --user-data-dir="%LOCALAPPDATA%\UICQuotationManager\Profile"
    exit /b
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="file:///%~dp0index.html" --window-size=1366,860 --allow-file-access-from-files --user-data-dir="%LOCALAPPDATA%\UICQuotationManager\Profile"
    exit /b
)

:: 3. Launch with Google Chrome
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="file:///%~dp0index.html" --window-size=1366,860 --allow-file-access-from-files --user-data-dir="%LOCALAPPDATA%\UICQuotationManager\Profile"
    exit /b
)

:: 4. Fallback default browser
start "" "%~dp0index.html"
exit /b
