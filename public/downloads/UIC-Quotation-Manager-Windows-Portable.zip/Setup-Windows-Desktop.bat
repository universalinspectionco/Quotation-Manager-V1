@echo off
setlocal
cd /d "%~dp0"
title UIC Quotation Manager - Desktop Setup
echo Creating Desktop shortcut for Universal Inspection Co. Quotation Manager...
set "TARGET=%~dp0UIC Quotation Manager.exe"
set "SHORTCUT=%USERPROFILE%\Desktop\UIC Quotation Manager.lnk"
set "ICON=%~dp0app-icon.ico"

powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%SHORTCUT%'); $s.TargetPath = '%TARGET%'; $s.WorkingDirectory = '%~dp0'; $s.IconLocation = '%ICON%'; $s.Description = 'Universal Inspection Co. Quotation & Price Book Manager'; $s.Save()"

echo.
echo [SUCCESS] Desktop shortcut created successfully on your Windows Desktop!
echo.
pause
