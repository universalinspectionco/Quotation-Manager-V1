@echo off
setlocal
cd /d "%~dp0"
title UIC Quotation Manager - Offline Web Server
echo ========================================================
echo   Universal Inspection Co. Ltd. (UIC)
echo   Quotation Manager - Offline Server Launcher
echo ========================================================
echo.
echo Starting local offline server on http://127.0.0.1:41731 ...
powershell -ExecutionPolicy Bypass -NoProfile -WindowStyle Hidden -Command "$p=41731;$l=New-Object System.Net.HttpListener;$l.Prefixes.Add('http://127.0.0.1:'+$p+'/');$l.Start();while($l.IsListening){try{$c=$l.GetContext();$r=$c.Request;$s=$c.Response;$u=$r.Url.LocalPath.TrimStart('/');if(!$u){$u='index.html'};$f=Join-Path (Get-Location) $u;if(Test-Path $f){$b=[System.IO.File]::ReadAllBytes($f);$ext=[System.IO.Path]::GetExtension($f).ToLower();$m=switch($ext){'.html'{'text/html; charset=utf-8'}.'js'{'application/javascript; charset=utf-8'}.'css'{'text/css; charset=utf-8'}.'json'{'application/json'}.'png'{'image/png'}.'svg'{'image/svg+xml'}.'ico'{'image/x-icon'}default{'application/octet-stream'}};$s.ContentType=$m;$s.ContentLength64=$b.Length;$s.OutputStream.Write($b,0,$b.Length)}else{$s.StatusCode=404};$s.OutputStream.Close()}catch{}}"
timeout /t 1 /nobreak >nul

if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app=http://127.0.0.1:41731/ --window-size=1366,860
    exit /b
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app=http://127.0.0.1:41731/ --window-size=1366,860
    exit /b
)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app=http://127.0.0.1:41731/ --window-size=1366,860
    exit /b
)
start http://127.0.0.1:41731/
exit /b
